from flask import Flask, jsonify, request, send_from_directory

from bot import chat

app = Flask(__name__, static_folder="static")


@app.get("/")
def home():
    return send_from_directory("static", "index.html")


@app.post("/chat")
def chat_endpoint():
    history = request.get_json().get("messages", [])[-20:]  # keep the last 20 turns
    if not history or history[-1].get("role") != "user":
        return jsonify({"reply": "Please type a question."}), 400
    return jsonify({"reply": chat(history)})


if __name__ == "__main__":
    app.run(port=5000, debug=True)
