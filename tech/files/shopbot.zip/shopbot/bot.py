import json
import re
import sqlite3
from pathlib import Path

import anthropic

MODEL = "claude-sonnet-5-5"   # or any model that supports tool use
DB_PATH = "shop.db"
DOCS_DIR = Path("docs")

client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY from the environment

SYSTEM_PROMPT = """You are the friendly shopping assistant for Your Shop.
Answer only questions about our products, orders and store policies.
Always use the tools to look up facts. Never invent products, prices,
stock levels, order details or policies. If the tools do not give you
the answer, say you don't know and suggest emailing support@yourshop.example.
To check an order, you need BOTH the order number and the email used to
place it. Keep answers short and friendly."""


# ---------- Part 1: your local files ----------

def load_docs():
    """Split every .md/.txt file in docs/ into paragraphs."""
    chunks = []
    for path in DOCS_DIR.glob("*"):
        if path.suffix.lower() not in (".md", ".txt"):
            continue
        for para in path.read_text(encoding="utf-8").split("\n\n"):
            if para.strip():
                chunks.append({"source": path.name, "text": para.strip()})
    return chunks


DOC_CHUNKS = load_docs()


def words(text):
    return set(re.findall(r"[a-z0-9]+", text.lower()))


def search_docs(query, top_k=3):
    """Return the paragraphs that share the most words with the query."""
    q = words(query)
    scored = [(len(q & words(c["text"])), c) for c in DOC_CHUNKS]
    scored = [s for s in scored if s[0] > 0]
    scored.sort(key=lambda s: s[0], reverse=True)
    return [c for _, c in scored[:top_k]] or [{"text": "No matching policy found."}]


# ---------- Part 2: your database ----------

def db():
    # Read-only connection: the bot can look, but never change data.
    conn = sqlite3.connect(f"file:{DB_PATH}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    return conn


def search_products(query="", max_price=None):
    sql = """SELECT name, category, price, stock, description FROM products
             WHERE (name LIKE ? OR category LIKE ? OR description LIKE ?)"""
    like = f"%{query}%"
    params = [like, like, like]
    if max_price is not None:
        sql += " AND price <= ?"
        params.append(max_price)
    with db() as conn:
        rows = conn.execute(sql + " LIMIT 10", params).fetchall()
    return [dict(r) for r in rows] or [{"result": "No matching products."}]


def get_order_status(order_id, email):
    with db() as conn:
        row = conn.execute(
            "SELECT id, status, total, placed_on FROM orders WHERE id = ? AND lower(email) = lower(?)",
            (order_id, email),
        ).fetchone()
    return dict(row) if row else {"result": "No order found with that number and email."}


# ---------- Part 3: tell the AI what tools it has ----------

TOOLS = [
    {
        "name": "search_products",
        "description": "Search the product catalogue by keyword (name, category or description). "
                       "Returns name, category, price, stock and description.",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Keyword, e.g. 'shoes' or 'electronics'"},
                "max_price": {"type": "number", "description": "Optional maximum price in USD"},
            },
            "required": ["query"],
        },
    },
    {
        "name": "get_order_status",
        "description": "Look up an order. Requires the order number and the customer's email.",
        "input_schema": {
            "type": "object",
            "properties": {
                "order_id": {"type": "integer"},
                "email": {"type": "string"},
            },
            "required": ["order_id", "email"],
        },
    },
    {
        "name": "search_docs",
        "description": "Search store policies and FAQs: shipping, returns, refunds, support, gift wrap.",
        "input_schema": {
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
        },
    },
]

TOOL_FUNCTIONS = {
    "search_products": search_products,
    "get_order_status": get_order_status,
    "search_docs": search_docs,
}


def run_tool(name, args):
    try:
        return TOOL_FUNCTIONS[name](**args)
    except Exception as e:  # never crash the chat because of one bad call
        return {"error": str(e)}


# ---------- Part 4: the conversation loop ----------

def chat(history):
    """history: list of {"role": "user"|"assistant", "content": "text"}"""
    messages = list(history)
    for _ in range(5):  # safety limit on tool rounds
        response = client.messages.create(
            model=MODEL,
            max_tokens=1024,
            system=SYSTEM_PROMPT,
            tools=TOOLS,
            messages=messages,
        )
        messages.append({"role": "assistant", "content": response.content})

        if response.stop_reason != "tool_use":
            return "".join(b.text for b in response.content if b.type == "text")

        results = []
        for block in response.content:
            if block.type == "tool_use":
                output = run_tool(block.name, block.input)
                results.append({
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": json.dumps(output),
                })
        messages.append({"role": "user", "content": results})

    return "Sorry, I couldn't finish that. Please try rephrasing your question."
