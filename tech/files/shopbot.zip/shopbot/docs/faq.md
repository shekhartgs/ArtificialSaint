# FAQ

Do you have a physical store? No, we are online only.

How do I contact support? Email support@yourshop.example, Monday to Friday, 9 am to 5 pm Pacific.

Do you offer gift wrapping? Yes, for $4 per item at checkout.
