import sqlite3

db = sqlite3.connect("shop.db")
db.executescript("""
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS orders;

CREATE TABLE products (
  id       INTEGER PRIMARY KEY,
  name     TEXT NOT NULL,
  category TEXT,
  price    REAL,
  stock    INTEGER,
  description TEXT
);

CREATE TABLE orders (
  id       INTEGER PRIMARY KEY,
  email    TEXT NOT NULL,
  status   TEXT,
  total    REAL,
  placed_on TEXT
);

INSERT INTO products (name, category, price, stock, description) VALUES
 ('Cotton T-shirt',      'Clothing',    19.99, 40, 'Soft 100% cotton tee, sizes S to XL'),
 ('Running Shoes',       'Footwear',    79.00, 12, 'Lightweight shoes with cushioned sole'),
 ('Steel Water Bottle',  'Accessories', 24.50,  0, 'Keeps drinks cold for 24 hours'),
 ('Yoga Mat',            'Fitness',     35.00,  8, 'Non-slip 6 mm mat with carry strap'),
 ('Wireless Earbuds',    'Electronics', 59.99, 25, '8-hour battery, noise reduction');

INSERT INTO orders (id, email, status, total, placed_on) VALUES
 (1001, 'asha@example.com', 'Shipped',    98.99, '2026-10-20'),
 (1002, 'ravi@example.com', 'Processing', 35.00, '2026-10-26');
""")
db.commit()
db.close()
print("shop.db created")
