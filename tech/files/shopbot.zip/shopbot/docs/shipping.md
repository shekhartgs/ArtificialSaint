# Shipping

We ship to all US states. Standard shipping takes 3 to 5 business days and is free on orders over $50. Express shipping takes 1 to 2 business days and costs $12.

Orders placed before 2 pm Pacific time on a business day ship the same day.
